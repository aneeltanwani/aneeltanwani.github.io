clear all;
%---------Mode 1 dynamics
Sys(1).A = zeros(2,2);
Sys(1).B = zeros(2,1);
Sys(1).C = [1 0];
Sys(1).D = zeros(1,1);
%---------Mode 2 dynamics
Sys(2).A = [0 1;-1 0];
Sys(2).B = zeros(2,1);
Sys(2).C = [0 0];
Sys(2).D = zeros(1,1);
%-------Run PlantData.mdl
Tfin = 20; StepSize = Tfin/2000;td = 1;NSteps = td/StepSize;
opt = simset('Solver', 'ode4', 'FixedStep', StepSize);
opt = simset(opt, 'InitialState', [5;3]);
[t] = sim('PlantData',[0,Tfin],opt);
x1 = SysStates.signals.values(:,1)';
x2 = SysStates.signals.values(:,2)';
x = [x1 x2];
y = SysOutput.signals.values(:,1)';
Sigma = SwitchSig.signals.values(:,1)';
time = Time.signals.values(:,1)';
%plot(time, x1, 'r');
%hold on
%plot(time, x2, 'b');
%plot(time, y)
%plot(time,Sigma)
%----Computing the switching time and mode sequence----%
ModeSeq(1) = Sigma(1);
Tau (1,1) = 0;
Tau(2,1) = 1;
j=2;
for(i = 2:size(time,2))
    if(Sigma(i) ~= Sigma(i-1))
        ModeSeq(j) = Sigma(i);
        Tau(1,j) = time(i);
        Tau(2,j) = i;
        j=j+1;
        i=i+1;
    elseif(Sigma(i) == Sigma(i-1))
        i=i+1;
    end
end
TotTrans = size(ModeSeq,2);
%---Defining the Theta Matrices
ThetaOdd = [1 cos(td);0 -sin(td)];
ThetaEven = [cos(td) cos(2*td);-sin(td) -sin(2*td)];
invThetaOdd = inv(ThetaOdd');
invThetaEven = inv(ThetaEven');
zinit = 0;
xi(:,1) = [0 0]';
xi(:,2) = [0 0]';
xHatIni = [-1 1]';
zHat=[];
xHat=[];
for(j=1:TotTrans-1)
    %----Run xHatPlant.mdl ----
    Aest = Sys(ModeSeq(j)).A;
    Best = Sys(ModeSeq(j)).B;
    Cest = [eye(size(Aest,1));Sys(ModeSeq(j)).C];
    Dest = [zeros(size(Aest,1),size(Best,2));Sys(ModeSeq(j)).D];
    opt = simset(opt, 'InitialState', xHatIni);
    [t] = sim('xHatPlant',Tau(1,j+1)-Tau(1,j),opt);
    yHat = xHatSim.signals.values(:,3)';
    xHat = [xHat xHatSim.signals.values(1:NSteps,1:2)'];
    xHatTmin = xHatSim.signals.values(NSteps+1,1:2)';
    %-----Compute output error
    yTild = yHat(1:size(yHat,2))-y(Tau(2,j):Tau(2,j+1));
    yTildSig = [time(Tau(2,j):Tau(2,j+1))'-time(Tau(2,j))' yTild'];
    %------z-dynamics
    opt = simset(opt, 'InitialState', zinit);
    S1=0;l1=2;%Pick the gain for z-estimator
    [t] = sim('zHatEst',Tau(1,j+1),opt);
    zHat = [zHat zHatSim.signals.values(1:NSteps,1)'];
    if(j>=3)
        if (j==3)
            xi(:,3) = invThetaOdd*[zHat(j*NSteps);zHat((j-2)*NSteps)-xi(1,1)-[cos(td) -sin(td)]*xi(:,2)];
            %xi(:,3) = [0 0]';
        elseif ((mod(j,2)==0))
            xi(:,j) = invThetaEven*[zHat((j-1)*NSteps)-xi(1,j-1);zHat((j-3)*NSteps)-xi(1,j-3)-[cos(td) -sin(td)]*(xi(:,j-2)+xi(:,j-1))];
        elseif ((mod(j,2) ~= 0))
            xi(:,j) = invThetaOdd*[zHat(j*NSteps);zHat((j-2)*NSteps)-xi(1,j-2)-[cos(td) -sin(td)]*xi(:,j-1)];
        end
    end
    xHatIni = xHatTmin - xi(:,j);
    j=j+1;
end
%-------Let the plotting begin
time = time(1:Tfin/StepSize);
x1 = x1(1:Tfin/StepSize);
x2 = x2(1:Tfin/StepSize);
xTild = xHat - [x1;x2];
for(i=1:size(xTild,2))
    xTildNorm(i) = norm(xTild(:,i));
end
Sigma = Sigma(1:Tfin/StepSize);
figure();
subplot(2,1,1)
plot(time,x1,'r');
hold on;
plot(time,xHat(1,:),'-.b');
hold off;
state1=legend('$x_1(t)$','$\hat{x}_1(t)$');
set(state1,'interpreter','latex','fontsize',20,'fontname','times new roman');
set(gca,'fontsize',16,'fontname','times new roman');
subplot(2,1,2)
plot(time,x2,'r');
hold on;
plot(time,xHat(2,:),'-.b');
hold off;
state2=legend('$x_2(t)$','$\hat{x}_2(t)$');
set(state2,'interpreter','latex','fontsize',20,'fontname','times new roman');
set(gca,'fontsize',16,'fontname','times new roman');
figure();
subplot(2,1,1)
plot(time,xTildNorm);
error=legend('$|\tilde{x}(t)|$');
set(error,'interpreter','latex','fontsize',24,'fontname','times new roman');
set(gca,'fontsize',16,'fontname','times new roman');
subplot(2,1,2)
plot(time,Sigma)
hSwSig=legend('$\sigma(t)$');
set(hSwSig,'interpreter','latex','fontsize',24,'fontname','times new roman');
ylim([0.5,2.5]);
set(gca,'fontsize',16,'fontname','times new roman');
