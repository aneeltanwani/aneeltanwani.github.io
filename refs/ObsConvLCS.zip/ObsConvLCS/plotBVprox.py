import numpy as np
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib import rc


rc('text', usetex = 1)

dataPlot = np.loadtxt('SingleDSObserverLCS.dat')

states = plt.figure(figsize=(8.6/2.54, 1.2*(7.0*2/3)/2.54))

x1 = states.add_subplot(211)
p = []
p.append(x1.plot(dataPlot[:, 0], dataPlot[:, 1])[0],)
p.append(x1.plot(dataPlot[:, 0], dataPlot[:, 3],'r--')[0],)
x1.grid(linewidth = 0.3)
x1.legend(p, [r'$x_1$']+[r'$\hat x_1$'], fontsize='24')

x2 = states.add_subplot(212)
p = []
p.append(x2.plot(dataPlot[:, 0], dataPlot[:, 2])[0],)
p.append(x2.plot(dataPlot[:, 0], dataPlot[:, 4],'r--')[0],)
x2.grid(linewidth = 0.3)
x2.legend(p, [r'$x_2$']+[r'$\hat x_2$'], fontsize='24')

x2.set_xlabel(r'$t$')


errInp = plt.figure(figsize=(8.6/2.54, 1.2*(7.0*2/3)/2.54))

err = errInp.add_subplot(211)
p = []
p.append(err.plot(dataPlot[:, 0], np.sqrt(dataPlot[:, 8]))[0],)
err.grid(linewidth = 0.3)
err.legend(p, [r'$|x - \hat x|$'], fontsize='24')

Inp = errInp.add_subplot(212)
p = []
p.append(Inp.plot(dataPlot[:, 0], dataPlot[:, 7])[0],)
Inp.grid(linewidth = 0.3)
Inp.legend(p, [r'$u$'], fontsize='24')

Inp.set_xlabel(r'$t$')

#fig.tight_layout(pad=0)
plt.show()