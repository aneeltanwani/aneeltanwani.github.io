
* Find "runme.m", which is the main file.
* You can just run "runme", and "nowplot" for plotting!
* Files whose names begin with capital letters are kernel files, and need not be modified.
* All other files are modified by users depending on their models.

* The first version had been developed for the case T_comp = 0.
* To incorporate the case T_comp > 0, we played a trick.
* First we run the synchronous observer as if T_comp = 0.
* Then, integrate only for $[t_{im},T_{im}+T_comp)$ using the already available data.
* Finally, "nowplot" takes care of the simulation results.

2011.2.9

2012.5.26	Bug fixed and model changed by Aneel