function out = x_to_xi(x)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Project: Hybrid Observer
% Author: H. Shim
% Version: 0.4 / Date: June 2011
%
% Requires: Obs.mode
% out: Column
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

global Obs

switch Obs.mode
    case 1
        out = [x(2); x(1)^2 - x(3)^2 + 2*x(1) + x(2)];
    case 2
        out = [x(1)^2 - x(3)^2 + 2*x(1)];
    case 3
        out = [x(1)+x(2)^2];
    otherwise
        error('x_to_xi: CASE error!');
end


