function out = x_to_z(x)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Project: Hybrid Observer
% Author: H. Shim
% Version: 0.4 / Date: June 2011
%
% Requires: Obs.mode
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

global Obs

switch Obs.mode
    case 1
        out = [];
    case 2
        out = [x(2)];
    case 3
        out = [x(2); x(1)^2 - x(3)^2 + 2*x(1) ];
    otherwise
        error('x_to_z: CASE error!');
end


