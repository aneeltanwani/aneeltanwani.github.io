function out = obs_z(in)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Project: Hybrid Observer
% Author: H. Shim
% Version: 0.4 / Date: June 2011
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

global  Plant Obs

nz = Obs.zdim(Obs.mode);
nci = Plant.CInputSize;
nxi = Obs.xidim(Obs.mode);
    
% setting
z = in(1:nz); % state
u = in(nz+1:nz+nci); % continuous input
xi = in(nz+nci+1:nz+nci+nxi);

% flow map
switch Obs.mode
    case 1
        error('no z-observer');
    case 2
        out = -z*xi;
    case 3
        out = [ -0.5*z(1); 2*(xi-z(1)^2+1)*z(1)^2 ];
    otherwise
        error('plant_f: CASE error!');
end
