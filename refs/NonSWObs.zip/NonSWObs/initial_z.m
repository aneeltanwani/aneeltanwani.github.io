function out = map_to_z(xi0,z0,xi1)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Project: Hybrid Observer
% Author: H. Shim
% Version: 0.4 / Date: June 2011
%
% Requires: Obs.mode
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

global Obs

switch Obs.mode
    case 1
        error('no z-observer for this');
    case 2
        out = [xi0(1)];
    case 3
        out = [z0; xi0(1)];
    otherwise
        error('x_to_xi: CASE error!');
end


