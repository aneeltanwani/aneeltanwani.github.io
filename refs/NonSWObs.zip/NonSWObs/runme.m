%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Hybrid Observer Simulator
% v. 0.5
% for Nonlinear Version ACC'11
% Coded by Hyungbo Shim
% 2011 June
% 2012 Jan for IJRNC

global Plant Sim Obs

% Simulation description
Sim.Time = 12;              % Simulation Time
Sim.MaxStepTime = Sim.Time/500; % Just for fine result; 
                            % Goes to Parameter set of all Simulink files
Sim.mdl_plant = 'MDL_pmodel';   % Name of Simulink files
Sim.mdl_obs_xi_f = 'MDL_xifmodel';
Sim.mdl_obs_xi_b = 'MDL_xibmodel';
Sim.mdl_obs_z = 'MDL_zmodel';
opt = simset('InitialStep',Sim.Time/2000);  % Simulation options

Plant.StateSize = 3;    % size of state
Plant.CInputSize = 1;   % size of continuous input; Minimum is 1; 
                        % set as 1 even if there's no input
Plant.DInputSize = 1;   % size of jump input; Not used in ACC'11 version
Plant.OutputSize = 1;   % size of output
Plant.IC = [1;1;1];     % Set your Initial Condition;   LIVE UPDATE
                        % "LIVE UPDATE' means that this value will be
                        % modified during the operation.

Plant.f = @plant_f;     % CT Dynamics m-file name
Plant.p = @plant_p;     % Jump m-file name
Plant.h = @plant_h;     % Output m-file name

Plant.mode = 0;         % Placeholder for current mode  LIVE UPDATE
                        % Do not touch.
                        
Obs.IC = [0;0;0];       % Initial condition of Sync Observer  LIVE UPDATE
Obs.N = 3;              % Set # of switchings for observability
Obs.xidim = [2;1;1];   % Dimensions of observable parts for each mode
Obs.zdim = [0;1;2];     % Dimensions of z state
Obs.xif = @obs_xif;     % Forward xi-observer file name
Obs.xib = @obs_xib;     % Backward xi-observer file name
Obs.z = @obs_z;         % z-observer file name
Obs.x_to_xi = @x_to_xi; % Coordinate change file name; x to xi
Obs.x_to_z = @x_to_z;
Obs.map_to_z = @initial_z;   % Reset map file name for IC of z
Obs.getxhat = @xiz_to_x;    % Inverse coordinate change from (xi,z) to x

Obs.mode = 0;           % Placeholder for current mode  LIVE UPDATE
                        % Do not touch.

                        
% Continuous Input;  USER DEFINES
%   first column: times
%   remaining column: values (multi-input possible)
%   (They will be interpolated.)
u = [0, Sim.Time; 0, 0]';

% Jump Input;  Not used
%   (The same as Input.)
v = [0, Sim.Time; 0, 0]';

% Switching scheme  USER DEFINES
%   first row: Switching times from the first switching time
%   second row: Mode before the corresponding switching time
SWtable = ...
 [ 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12;
   1, 2, 3, 1, 2, 3, 1, 2, 3,  1,  2,  3];


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Users do not have to modify the rest.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

   % making the SW structure from SWtable
   [tmp,Nmode] = size(SWtable);     % OBTAIN Nmode; Number of modes
   for i=1:Nmode
      SW(i).time = SWtable(1,i);
      SW(i).mode = SWtable(2,i);
      if i>1
          SW(i).duration = SW(i).time - SW(i-1).time;
      else
          SW(i).duration = SW(i).time;
      end
   end


   
%% Plant Run   
disp('Now I run your plant!')

  for i=1:Nmode
      str = sprintf('mode = %d',i); disp(str);
      Plant.mode = SW(i).mode;  % goes to simulator
      %opt = simset('InitialStep',Sim.Time/1000);    % You can add more settings
      if i>1
          starttime = SW(i-1).time;
      else
          starttime = 0;
      end
      endtime = SW(i).time; 
      
      % Run simulator!
      sim(Sim.mdl_plant, [starttime, endtime], opt);
      prec(i).mode = SW(i).mode;    % prec: Plant Recorder          
      prec(i).tInit = starttime;     
      prec(i).tFinal = endtime;
      prec(i).t = plant_t;
      prec(i).x = plant_x;
      prec(i).y = plant_y;
      prec(i).xInit = Plant.IC;
      prec(i).xFinal = xFinal';  % coming from Simulink model as row vector
      lx = size(plant_t,1);
      prec(i).xi = zeros( lx, Obs.xidim(SW(i).mode) );
      prec(i).z = zeros( lx, Obs.zdim(SW(i).mode) );
      for j=1:lx
          Obs.mode = SW(i).mode;    % delivers to x_to_xi, x_to_z
          prec(i).xi(j,:) = Obs.x_to_xi( plant_x(j,:)' )';   % returns column
          out = Obs.x_to_z( plant_x(j,:)' )';   % returns [] when q mod m = 1
          if size(out,2) ~= 0
              prec(i).z(j,:) = out;
          end
      end
      
      % Jump map implementation; xFinal is a row vector.
      Plant.IC = Plant.p([xFinal, ...
          interp1(u(:,1),u(:,2:Plant.CInputSize+1),SW(i).time), ...
          interp1(v(:,1),v(:,2:Plant.DInputSize+1),SW(i).time)]');
  end
  
   %%% Making array records of t, x, y
   pt = [];  px = [];  py = [];
   for i=1:Nmode;
       pt = [pt; prec(i).t];
       px = [px; prec(i).x];
       py = [py; prec(i).y];
   end
   
   
   
%% Observer Run   
disp('Now I run your observer!')

  ObsLoop = floor(Nmode/Obs.N);      % # of outer-loop
  ONmode = ObsLoop*Obs.N;            % # of total observer's modes
  Plant.IC = Obs.IC;  % setting observer's IC
  for m=1:ObsLoop
    for i=1:Obs.N
      k = i+(m-1)*Obs.N;     % mode number
      str = sprintf('mode = %d',k); disp(str);
      Plant.mode = SW(k).mode;  % affects simulator
      if k>1
          starttime = SW(k-1).time;
      else
          starttime = 0;
      end
      endtime = SW(k).time; 
            
      % Run simulator!
      %opt = simset('InitialStep',Sim.Time/1000);
      sim(Sim.mdl_plant, [starttime, endtime], opt);
      sorec(k).mode = SW(k).mode;    % prec: Plant Recorder          
      sorec(k).tInit = starttime;     
      sorec(k).tFinal = endtime;
      sorec(k).t = plant_t;
      sorec(k).x = plant_x;
      sorec(k).y = plant_y;
      sorec(k).xInit = Plant.IC;
      sorec(k).xFinal = xFinal';  % coming from Simulink model
      
      if i ~= Obs.N     % At last mode, the update occurs after getting
                        % new estimate later. 
                        % xFinal is a row vector
        Plant.IC = Plant.p([xFinal, ...
          interp1(u(:,1),u(:,2:Plant.CInputSize+1),SW(k).time), ...
          interp1(v(:,1),v(:,2:Plant.DInputSize+1),SW(k).time)]');
      end
    end
    
    % Estimate Update
    %  - observer gains are pre-determined in the files
    for i=1:Obs.N
      k = i+(m-1)*Obs.N;
      str = sprintf('partial observer mode = %d',k); disp(str);
      Obs.mode = SW(k).mode;    % affecting in the integration
      
      % Forward Evaluation
      Obs.IC = Obs.x_to_xi( sorec(k).xInit );
      if k>1
          starttime = SW(k-1).time;
      else
          starttime = 0;
      end
      endtime = SW(k).time;
      % Run simulator!
      %opt = simset('InitialStep',Sim.Time/1000);
      sim(Sim.mdl_obs_xi_f, [starttime, endtime], opt);
      pofrec(k).tInit = starttime;   % pofrec: Partial Obs Forward Rec
      pofrec(k).tFinal = endtime;
      pofrec(k).mode = Obs.mode;
      pofrec(k).t = obs_t;
      pofrec(k).xi = obs_x;
      pofrec(k).xiInit = Obs.IC;
      pofrec(k).xiFinal = xFinal';  % coming from Simulink model
      
      % cutting the latter half and record them in porec!
      lx = size(pofrec(k).t,1);
      halftime = SW(k).time - SW(k).duration/2;
      for j=1:lx
          if pofrec(k).t(j) > halftime 
              break;
          end
      end
      porec(k).t = [halftime; pofrec(k).t(j:lx)];   % Partial Obs Rec
      porec(k).xi = [interp1(pofrec(k).t, pofrec(k).xi, halftime); ...
          pofrec(k).xi(j:lx,:)];
      
      % Backward Evaluation
      
      % selecting u for the interval
      FF = 30;  % FineFactor: a TUNING FACTOR for details of u
      t_b = [0:SW(k).duration/FF:SW(k).duration]'; 
                % Time index for backward integration
      if k>1
          u_b = [ t_b, ...
                interp1(u(:,1),u(:,2:1+Plant.CInputSize), ...
                [SW(k).time:-SW(k).duration/FF:SW(k-1).time]') ];
      else
          u_b = [ t_b, ...
                interp1(u(:,1),u(:,2:1+Plant.CInputSize), ...
                [SW(k).time:-SW(k).duration/FF:0]') ];
      end   % u_b will be fed into the sim model.
      lx = size(prec(k).t,1);
      y_b = [ SW(k).time - prec(k).t(lx:-1:1), prec(k).y(lx:-1:1) ];
            % y_b will be fed into the sim model
      Obs.IC = pofrec(k).xiFinal;
            
      % Run simulator!
      %opt = simset('InitialStep',Sim.Time/1000);
      sim(Sim.mdl_obs_xi_b, [0, SW(k).duration], opt);
      lx = size(obs_t,1);
      pobrec(k).t = SW(k).time - obs_t(lx:-1:1);  % pobrec: Partial Obs Backward Rec
      pobrec(k).xi = obs_x(lx:-1:1,:);
      pobrec(k).xiInit = xFinal';
      pobrec(k).xiFinal = Obs.IC;
        % Note that pobrec uses the time index in forward direction!
      
      % cutting the latter half, reverse and record it
      halftime = SW(k).time - SW(k).duration/2;
      for j=lx:-1:1
          if pobrec(k).t(j) < halftime 
              break;
          end
      end
      % recording for porec: Partial Obs Rec; 
      % Append it to porec(k)
      %  - overlapped at halftime (for sharp jump)
      porec(k).t = [ pobrec(k).t(1:j); ...
          halftime; porec(k).t];
      porec(k).xi = [ pobrec(k).xi(1:j,:); ...
          interp1(pobrec(k).t, pobrec(k).xi, halftime); ...
          porec(k).xi ];
           
      % z-observer
      if i>1    % there's no z-observer when q mod m = 1
        if i>2  % i: q mod m, k: mode
          Obs.IC = Obs.map_to_z( pofrec(k-1).xiFinal, zorec(k-1).zFinal, ...
            pobrec(k).xiInit );
        else
          Obs.IC = Obs.map_to_z( pofrec(k-1).xiFinal, 0, pobrec(k).xiInit );
        end
        % Run simulator!
        %opt = simset('InitialStep',Sim.Time/1000);
        sim(Sim.mdl_obs_z, [SW(k-1).time, SW(k).time], opt);
        zorec(k).t = obs_t; % zorec: Z Obs Rec
        zorec(k).z = obs_x;
        zorec(k).zInit = Obs.IC;
        zorec(k).zFinal = xFinal';        
      end
    end
    
    % Finally update the estimate
    xhat = Obs.getxhat(pofrec(k).xiFinal, zorec(k).zFinal);
    Plant.IC = Plant.p([xhat', ...
          interp1(u(:,1),u(:,2:Plant.CInputSize+1),SW(k).time), ...
          interp1(v(:,1),v(:,2:Plant.DInputSize+1),SW(k).time)]');
  end
    
%%% Making records of t, x, y
sot = [];  sox = [];  soy = [];
for i=1:ONmode;
    sot = [sot; sorec(i).t];
    sox = [sox; sorec(i).x];
    soy = [soy; sorec(i).y];
end

%% Real world Observer Run   
disp('Now I emulate the real world observer!')
Tcomp = 0.5; % should be less than any switching period!
Obs.IC = [0;0;0];
rwsot = [];  rwsox = [];  rwsoy = [];

  ObsLoop = floor(Nmode/Obs.N);      % # of outer-loop
  ONmode = ObsLoop*Obs.N;            % # of total observer's modes
  for m=2:ObsLoop
      k = 1+(m-1)*Obs.N;     % mode number
      str = sprintf('mode = %d',k); disp(str);
      starttime = SW(k-1).time;
      endtime = starttime + Tcomp;

      Plant.mode = SW(k-1).mode;  % affects Plant.p 
      Plant.IC = Plant.p([sorec(k-1).xFinal; ...
          interp1(u(:,1),u(:,2:Plant.CInputSize+1),SW(k-1).time); ...
          interp1(v(:,1),v(:,2:Plant.DInputSize+1),SW(k-1).time)]');
      Plant.mode = SW(k).mode;  % affects simulator

      % Run simulator!
      %opt = simset('InitialStep',Sim.Time/1000);
      sim(Sim.mdl_plant, [starttime, endtime], opt);
      rwsorec(k).mode = SW(k).mode;    % prec: Plant Recorder          
      rwsorec(k).tInit = starttime;     
      rwsorec(k).tFinal = endtime;
      rwsorec(k).t = plant_t;
      rwsorec(k).x = plant_x;
      rwsorec(k).y = plant_y;
      rwsorec(k).xInit = Plant.IC;
      rwsorec(k).xFinal = xFinal';  % coming from Simulink model

      rwsot = [rwsot; rwsorec(k).t];
      rwsox = [rwsox; rwsorec(k).x];
      rwsoy = [rwsoy; rwsorec(k).y];

  end

  
  
%% Plot

%nowplot;
