function out = plant_h(z)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Project: Hybrid Observer
% Author: H. Shim
% Version: 0.4 / Date: June 2011
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

global  Plant 

ns = Plant.StateSize;
nci = Plant.CInputSize;
ndi = Plant.DInputSize;
    
% setting
x = z(1:ns); % state
u = z(ns+1:ns+nci); % continuous input
v = z(ns+nci+1:ns+nci+ndi); % jump input

% flow map
out = zeros(1,1);
switch Plant.mode
    case 1
        out = x(2);
    case 2
        out = x(1)^2 - x(3)^2 + 2*x(1);
    case 3
        out = x(1) + x(2)^2;
    otherwise
        error('plant_h: CASE error!');
end
