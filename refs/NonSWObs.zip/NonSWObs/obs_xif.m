function out = obs_xif(in)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Project: Hybrid Observer
% Author: H. Shim
% Version: 0.4 / Date: June 2011
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

global  Plant Obs

ns = Obs.xidim(Obs.mode);
nci = Plant.CInputSize;
no = Plant.OutputSize;
    
% setting
x = in(1:ns); % state
u = in(ns+1:ns+nci); % continuous input
y = in(ns+nci+1:ns+nci+no); % jump input

% flow map
L1 = [2; 1];
L2 = 4;
L3 = 4;
switch Obs.mode
    case 1
        out = [x(2)-x(1); x(2)-x(1)] + L1*(y - x(1));
    case 2
        out = 0 + L2*(y - x(1));
    case 3
        out = 0 + L3*(y - x(1));
    otherwise
        error('obs_xif: CASE error!');
end
