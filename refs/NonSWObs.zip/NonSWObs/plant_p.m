function out = plant_p(z)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Project: Hybrid Observer
% Author: H. Shim
% Version: 0.4 / Date: June 2011
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

global  Plant

ns = Plant.StateSize;
nci = Plant.CInputSize;
ndi = Plant.DInputSize;

% setting
x = z(1:ns); % state
u = z(ns+1:ns+nci); % continuous input
v = z(ns+nci+1:ns+nci+ndi); % jump input

% flow map
switch Plant.mode
    case 1
        out = zeros(3,1);
        out(1) = 0.5*x(3);
        out(2) = x(2);
        out(3) = 0.5*x(1);
    case 2
        out = x;
    case 3
        out = x;
    otherwise
        error('plant_p: CASE error!');
end
