function out = plant_f(z)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Project: Hybrid Observer
% Author: H. Shim
% Version: 0.4 / Date: June 2011
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

global  Plant

ns = Plant.StateSize;
nci = Plant.CInputSize;
ndi = Plant.DInputSize;
    
% setting
x = z(1:ns); % state
u = z(ns+1:ns+nci); % continuous input
v = z(ns+nci+1:ns+nci+ndi); % jump input

% flow map
out = zeros(3,1);
switch Plant.mode
    case 1
        out(1) = 0.1*x(3);
        out(2) = x(1)^2 - x(3)^2 + 2*x(1);
        out(3) = 0.1*(x(1) + 1);
    case 2
        out(1) = x(3);
        out(2) = -(x(1)^2 - x(3)^2 + 2*x(1))*x(2);
        out(3) = (x(1) + 1);
    case 3
        out(1) = x(2)^2;
        out(2) = -0.5*x(2);
        out(3) = 0;
    otherwise
        error('plant_f: CASE error!');
end
