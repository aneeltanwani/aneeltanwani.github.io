%% Plot

close all

TT=[];
XX=[];
XHAT=[];
XSTAR=[];
Tpiece = 0.1;
Tcomp = 0.5;

for i=1:10
    if ismember(i, [4,7,10])
        
        Tchunk = ((i-1):Tpiece:(i-1)+Tcomp)'; 
        TT = [TT; Tchunk];
        XX = [XX; interp1(prec(i).t,prec(i).x,Tchunk)];
        XSTAR = [XSTAR; interp1(sorec(i).t,sorec(i).x,Tchunk)];
        XHAT = [XHAT; interp1(rwsorec(i).t,rwsorec(i).x,Tchunk)];
        
        Tchunk = ((i-1)+Tcomp:Tpiece:i)'; 
        TT = [TT; Tchunk];
        XX = [XX; interp1(prec(i).t,prec(i).x,Tchunk)];
        XSTAR = [XSTAR; interp1(sorec(i).t,sorec(i).x,Tchunk)];
        XHAT = [XHAT; interp1(sorec(i).t,sorec(i).x,Tchunk)];
        
    else
        
        Tchunk = ((i-1):Tpiece:i)';
        TT = [TT; Tchunk];        
        XX = [XX; interp1(prec(i).t,prec(i).x,Tchunk)];
        XSTAR = [XSTAR; interp1(sorec(i).t,sorec(i).x,Tchunk)];
        XHAT = [XHAT; interp1(sorec(i).t,sorec(i).x,Tchunk)];
        
    end
end

no = size(TT,1);
ERR = zeros(no,1);
RWERR = zeros(no,1);
for j=1:no,
    ERR(j) = norm(XSTAR(j,:)-XX(j,:));
    RWERR(j) = norm(XHAT(j,:)-XX(j,:));
end


figure(10)
subplot(2,1,1)
plot(TT,XX(:,1),':k','LineWidth',2);
hold on;
plot(TT,XHAT(:,1),'--r','LineWidth',2)
%interpreter latex
axis tight
title('Estimation for $x_1(t)$','Interpreter','latex','Fontsize',12)

subplot(2,1,2)
plot(TT,XX(:,2),':k','LineWidth',2);
hold on;
plot(TT,XHAT(:,2),'--r','LineWidth',2)
axis tight
title('Estimation for $x_2(t)$','Interpreter','latex','Fontsize',12)

figure(11)
subplot(2,1,1)
plot(TT,RWERR,'b','LineWidth',2);
axis tight
grid on
title('Norm of estimation error','Interpreter','latex','Fontsize',12)

subplot(2,1,2)
plot(prec(2).t, prec(2).xi, ':k','LineWidth',2)
hold on
plot(pofrec(2).t, pofrec(2).xi, '-.m','LineWidth',1)
plot(pobrec(2).t, pobrec(2).xi, '-.g','LineWidth',1)
plot(porec(2).t, porec(2).xi, '--r','LineWidth',2)
title('Estimation of $\xi$-observer at mode 2','Interpreter','latex','Fontsize',12)      

break;


%%% plot everything
for i=1:ObsLoop
figure(i)
  for j=1:Obs.N
      k = (i-1)*Obs.N + j;
      
      subplot(Obs.N,3,j)
      str=sprintf('xi, mode=%d',k);
      plot(prec(k).t, prec(k).xi, 'k')
      hold on
      plot(pofrec(k).t, pofrec(k).xi, ':')
      plot(pobrec(k).t, pobrec(k).xi, '--')
      title(str)
      plot(porec(k).t, porec(k).xi, 'r')
      
      subplot(Obs.N,3,Obs.N+j)
      str=sprintf('Err. in xi, mode=%d',k);
      [et,ee] = M_errplot(pofrec(k).t,pofrec(k).xi, prec(k).t, prec(k).xi,30,0);
      plot(et,ee,':')
      hold on
      [et,ee] = M_errplot(pobrec(k).t,pobrec(k).xi, prec(k).t, prec(k).xi,30,0);
      plot(et,ee,'--')
      title(str)
      
      if j ~= 1
        subplot(Obs.N,3,2*Obs.N+j)
        plot(prec(k).t, prec(k).z)
        hold on
        plot(zorec(k).t, zorec(k).z, ':')
        str=sprintf('z, mode=%d',k);
        title(str)
      end
      
  end
end
