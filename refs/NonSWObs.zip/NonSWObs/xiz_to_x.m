function out = get_xhat(xi,z)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Project: Hybrid Observer
% Author: H. Shim
% Version: 0.4 / Date: June 2011
%
% out : column vector
% This is not mode-dependent because it doesn't have to.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

out = zeros(3,1);
out(2) = z(1);
out(1) = xi - out(2)^2;
if (out(1)^2 + 2*out(1) - z(2)) < 0,
    error('xiz_to_x: sqrt negative!')
end
out(3) = sqrt(out(1)^2 + 2*out(1) - z(2));
