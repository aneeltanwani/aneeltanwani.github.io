clear all;
%---------Mode 1 dynamics
Sys(1).A = zeros(2,2);
Sys(1).B = zeros(2,1);
Sys(1).C = [1 0];
Sys(1).D = zeros(1,1);
%---------Mode 2 dynamics
eps = 0.1;
Sys(2).A = [eps 1;-1 eps];
Sys(2).B = zeros(2,1);
Sys(2).C = [0 0];
Sys(2).D = zeros(1,1);
%-------Run PlantData.mdl
Tfin = 14; StepSize = Tfin/1400;td = 1;NSteps = td/StepSize;
Tcomp=0.5*td; StepsBefore = Tcomp/StepSize; StepsAfter=(td-Tcomp)/StepSize;
opt = simset('Solver', 'ode4', 'FixedStep', StepSize);
opt = simset(opt, 'InitialState', [20;20]);
[t] = sim('PlantData',[0,Tfin],opt);
x1 = SysStates.signals.values(:,1)';
x2 = SysStates.signals.values(:,2)';
x = [x1 x2];
y = SysOutput.signals.values(:,1)';
Sigma = SwitchSig.signals.values(:,1)';
time = Time.signals.values(:,1)';
%plot(time, x1, 'r');
%hold on
%plot(time, x2, 'b');
%plot(time, y)
%plot(time,Sigma)
%----Computing the switching time and mode sequence----%
ModeSeq(1) = Sigma(1);
Tau (1,1) = 0;
Tau(2,1) = 1;
j=2;
for(i = 2:size(time,2))
    if(Sigma(i) ~= Sigma(i-1))
        ModeSeq(j) = Sigma(i);
        Tau(1,j) = time(i);
        Tau(2,j) = i;
        j=j+1;
%        i=i+1;
%    elseif(Sigma(i) == Sigma(i-1))
%        i=i+1;
    end
end
TotTrans = size(ModeSeq,2)-1;
%---Defining the Theta Matrices
ThetaOdd = [1 cos(td);0 -sin(td)];
ThetaEven = [cos(td) cos(2*td);-sin(td) -sin(2*td)];
invThetaOdd = inv(ThetaOdd');
invThetaEven = inv(ThetaEven');
zinit = 0;
xi(:,1) = [0 0]';
xi(:,2) = [0 0]';
xi(:,3) = [0 0]';
xHatIni = [10 10]';
zHat=[];
xHat=[];
yHat=[];
%---Some additional notations to run the loop faster (not in the paper)---
EvOddVec = [cos(td) -sin(td)];
EvenVec = [cos(2*td) -sin(2*td)];
A2 = Sys(2).A;
Mat0 = expm(A2*td);
Mat1 = expm(A2*(td-Tcomp));
Mat2 = expm(A2*(2*td-Tcomp));
Mat4 = expm(A2*Tcomp);
for(j=1:TotTrans)
    %----Run xHatPlant.mdl ----
    Aest = Sys(ModeSeq(j)).A;
    Best = Sys(ModeSeq(j)).B;
    Cest = [eye(size(Aest,1));Sys(ModeSeq(j)).C];
    Dest = [zeros(size(Aest,1),size(Best,2));Sys(ModeSeq(j)).D];
    %-----Let the xHatPlant run without estimate update --------
    opt = simset(opt, 'InitialState', xHatIni);
    [t] = sim('xHatPlant',Tcomp,opt);
    yHat = [yHat xHatSim.signals.values(1:StepsBefore,3)'];
    xHat = [xHat xHatSim.signals.values(1:StepsBefore,1:2)'];
    xHatTmin = xHatSim.signals.values(StepsBefore+1,1:2)';
    if (j >1)
        xHatUpdate = xHatTmin - xi(:,j-1);
    else
        xHatUpdate = xHatTmin;
    end
    %-----Introduce the correction term and runxHatPlant again -------
    opt = simset(opt, 'InitialState', xHatUpdate);
    [t] = sim('xHatPlant',Tau(1,j+1)-Tau(1,j)-Tcomp,opt);
    yHat = [yHat xHatSim.signals.values(:,3)'];
    xHat = [xHat xHatSim.signals.values(1:StepsAfter,1:2)'];
    xHatIni = xHatSim.signals.values(StepsAfter+1,1:2)';
    %-----Compute output error
    yTild = yHat(1:size(yHat,2)-1)-y(Tau(2,j):Tau(2,j+1)-1);
    yTildSig = [time(Tau(2,j):Tau(2,j+1)-1)'-time(Tau(2,j))' yTild'];
    yHat=[];
    %------z-dynamics
    opt = simset(opt, 'InitialState', zinit);
    S1=0;l1=20;%Pick the gain for z-estimator, should be greater than 4.1
    [t] = sim('zHatEst',Tcomp,opt);
    zHat = [zHat zHatSim.signals.values(1:StepsBefore,1)'];
    if(j>1)
        zUpdate = zHatSim.signals.values(StepsBefore+1,1)'- xi(1,j-1);
    else
        zUpdate = zHatSim.signals.values(StepsBefore+1,1)';
    end
    opt = simset(opt, 'InitialState', zUpdate);
    [t] = sim('zHatEst',Tau(1,j+1)-Tau(1,j)-Tcomp,opt);
    zHat = [zHat zHatSim.signals.values(1:StepsAfter,1)'];
    if(j>3)
        if ((mod(j,2)==0))
            xi(:,j) = invThetaEven*[exp(eps*td)*zHat((j-1)*NSteps)-EvOddVec*Mat1*xi(:,j-1);
                exp(2*eps*td)*zHat((j-3)*NSteps)-EvenVec*(Mat2*xi(:,j-3)+Mat0*xi(:,j-2)+Mat1*xi(:,j-1))];
        elseif ((mod(j,2) ~= 0))
            xi(:,j) = invThetaOdd*[zHat(j*NSteps);
                exp(eps*td)*zHat((j-2)*NSteps)-EvOddVec*(Mat1*xi(:,j-2)+xi(:,j-1))];
            xi(:,j) = Mat4*xi(:,j);
        end
    end
    %j=j+1;
end
%-------Let the plotting begin
time = time(1:Tfin/StepSize);
x1 = x1(1:Tfin/StepSize);
x2 = x2(1:Tfin/StepSize);
xTild = xHat - [x1;x2];
for(i=1:size(xTild,2))
    xTildNorm(i) = norm(xTild(:,i));
end
Sigma = Sigma(1:Tfin/StepSize);
figure();
subplot(2,1,1)
plot(time,x1,'r');
hold on;
plot(time,xHat(1,:),'-.b');
hold off;
state1=legend('$x_1(t)$','$\hat{x}_1(t)$');
set(state1,'interpreter','latex','fontsize',20,'fontname','times new roman');
set(gca,'fontsize',20,'fontname','times new roman');
subplot(2,1,2)
plot(time,x2,'r');
hold on;
plot(time,xHat(2,:),'-.b');
hold off;
state2=legend('$x_2(t)$','$\hat{x}_2(t)$');
set(state2,'interpreter','latex','fontsize',20,'fontname','times new roman');
set(gca,'fontsize',20,'fontname','times new roman');
figure();
subplot(2,1,1)
plot(time,xTildNorm,'LineWidth',3);
error=legend('$|\tilde{x}(t)|$');
set(error,'interpreter','latex','fontsize',24,'fontname','times new roman');
set(gca,'fontsize',20,'fontname','times new roman');
LabelPos = [0:td:Tfin 4+Tcomp:1:Tfin-Tcomp];
LabelPos = sort(LabelPos);
set(gca,'XTick',LabelPos);
%set(gca,'XTickLabel',LabelPos);
format_ticks(gca,{'$0$','$1$','$2$','$3$','$4$','$\hat{t}_1$','$5$','$\hat{t}_2$','$6$','$\hat{t}_3$','$7$','$\hat{t}_4$','$8$','$\hat{t}_5$','$9$','$\hat{t}_6$','$10$','$\hat{t}_7$','$11$','$\hat{t}_8$','$12$','$\hat{t}_9$','$13$','$\hat{t}_{10}$','$14$'});
subplot(2,1,2)
plot(time,Sigma,'LineWidth',3)
hSwSig=legend('$\sigma(t)$');
set(hSwSig,'interpreter','latex','fontsize',24,'fontname','times new roman');
ylim([0.5,2.5]);
set(gca,'fontsize',20,'fontname','times new roman');
set(gca,'XTick',0:td:Tfin)
