#include <stdio.h>
#include <math.h>

//0.0007
#define TOL_Q 0

extern "C" void computeFExt(double time, unsigned int sizeOfB, double* b, unsigned int sizeOfZ, double* z)
{
  double Grav = -9.81;
  double l = z[sizeOfZ-2];
  b[0] = Grav-l*l*z[0];
}

extern "C" void comph0(unsigned int sizeOfx, double* x, unsigned int sizeOfy, double* y, unsigned int sizeOfZ, double* z)
{
  double e = z[sizeOfZ-1];
//  printf("%f ", z[0]);
//  printf("%f\n", z[1]);
  if (z[0] > TOL_Q)
    y[0] = 1;
  else
  {
    y[0]= x[0]+e*z[1];
//    printf("q = %f ", z[0]);
//    printf("z_k = %f ", z[1]);
//    printf("x = %f ", x[0]);
//    printf("y = %f\n", y[0]);

  }

}

extern "C" void compg0(unsigned int sizeOflambda, double* lambda, unsigned int sizeOfr, double* r, unsigned int sizeOfZ, double* z)
{
  if (z[0] > TOL_Q)
    r[0] = 0;
  else
    r[0] = lambda[0];
}

extern "C" void compGradh(unsigned int sizeOfx, double* x, unsigned int sizeOfy, double* y, unsigned int sizeOfZ, double* z)
{
  if (z[0] > TOL_Q)
    y[0]= 0;
  else
    y[0]= 1;
}

extern "C" void compF(unsigned int sizeOfx, double* x, unsigned int sizeOfF, double* f, unsigned int sizeOfZ, double* z)
{
  double e = z[sizeOfZ-1];
  if (z[0] > TOL_Q)
  {
    f[0] = 100000;
    f[1] = 0;
  }
  else
    f[0] = 0;
    f[1] = e;
}

extern "C" void compGradg(unsigned int sizeOflambda, double* lambda, unsigned int sizeOfr, double* r, unsigned int sizeOfZ, double* z)
{
  if (z[0] > TOL_Q)
    r[0] = 0;
  else
    r[0] = 1;
}
