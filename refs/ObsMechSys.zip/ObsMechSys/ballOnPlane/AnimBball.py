import numpy as np
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
import matplotlib.animation as animation

# This example uses subclassing, but there is no reason that the proper function
# couldn't be set up and then use FuncAnimation. The code is long, but not
# really complex. The length is due solely to the fact that there are a total
# of 9 lines that need to be changed for the animation as well as 3 subplots
# that need initial set up.

dataBball = np.loadtxt('dataBball.txt')
Gain = -0.9
cnt = 0
Btime = []
BPos = []
BVel = []
ObsVel = []
while cnt < dataBball[:,0].size:
	Btime.append(dataBball[cnt,0])
	BPos.append(dataBball[cnt,1])
	BVel.append(dataBball[cnt,2])
	ObsVel.append(dataBball[cnt,5]-Gain*dataBball[cnt,1])
	cnt+=5

Con = [0]*len(Btime)

class SubplotAnimation(animation.TimedAnimation):
	def __init__(self):
		fig = plt.figure()
		#fig.set_size_inches(2.52, 3.25, True)
		ax1 = fig.add_subplot(211)
		ax2 = fig.add_subplot(212)
		
		self.t = np.array(Btime).reshape(-1,1)
		self.pos = BPos
		self.vel = BVel
		self.vest = ObsVel
		
		ax1.set_xlabel('Time')
		ax1.set_ylabel('Position')
		self.line1 = Line2D([], [], color ='red', marker='o', markeredgecolor='black')
		self.line1a = Line2D([], [], color ='black', linewidth=2)
		ax1.add_line(self.line1)
		ax1.add_line(self.line1a)
		ax1.set_xlim(0,10)
		ax1.set_ylim(-0.1,1.1)
		ax1.grid()
		ax1.set_title('Observer for Ball Bouncing on a Floor')
		
		ax2.set_xlabel('Time')
		ax2.set_ylabel('Velocity')
		self.line2 = Line2D([], [], color = 'blue',linewidth=2)
		self.line2a = Line2D([], [], color = 'red',linewidth=2)
		ax2.add_line(self.line2)
		ax2.add_line(self.line2a)
		ax2.legend([self.line2, self.line2a], [r'$v$',r'$\hat{v}$'])
		ax2.set_xlim(0,10)
		ax2.set_ylim(-15,15)
		ax2.grid()
		
		animation.TimedAnimation.__init__(self, fig, interval=20, blit=True)

	def _draw_frame(self, framedata):
		i = framedata
		
		self.line1.set_data(self.t[:i],self.pos[:i])
		
		self.line2.set_data(self.t[:i],self.vel[:i])
		self.line2a.set_data(self.t[:i],self.vest[:i])
		
		self._draw_artists = [self.line1, self.line2, self.line2a]

	def new_frame_seq(self):
		return iter(range(len(self.t)))

	def _init_draw(self):
		self.line1a.set_data(Btime[:], Con[:])
		lines = [self.line1, self.line2, self.line2a]
		for l in lines:
			l.set_data([], [])

ani = SubplotAnimation()
ani.save('Bball.mov', extra_args=['-vcodec', 'libxvid'],dpi=200,bitrate=4000)
#plt.show()
