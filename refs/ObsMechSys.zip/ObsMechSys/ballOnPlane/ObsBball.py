from Siconos.Kernel import *

import matplotlib.pyplot as plt
from matplotlib import rc

from mpl_toolkits.axes_grid.inset_locator import inset_axes
from mpl_toolkits.axes_grid.inset_locator import mark_inset
from matplotlib.ticker import FixedLocator, FormatStrFormatter

from multiprocessing import Pool
import itertools

from numpy import array, eye, empty

rc('text', usetex = 1)

t0 = 0      # start time
T = 10      # end time
r = 0.1     # ball radius
g = 9.81    # gravity
m = 1       # ball mass
e = 0.9     # restitution coeficient
theta = 0.5 # theta scheme

def run_sim(h, l, z0):
    #
    # dynamical system
    #
    x = array([1,0,0]) # initial position
    v = array([0,0,0]) # initial velocity
    mass = eye(3)      # mass matrix
    mass[2,2]=3./5 * r * r

    # the dynamical system
    ball = LagrangianLinearTIDS(x, v, mass)

    # set external forces
    weight = array([-m * g, 0, 0])
    ball.setFExtPtr(weight)

    #
    # Interactions
    #

    # ball-floor
    H = array([[1,0,0]])

    nslaw = NewtonImpactNSL(e)
    relation = LagrangianLinearTIR(H)
    inter = Interaction(1, nslaw, relation)

    #
    # Model
    #
    bouncingBall = Model(t0,T)

    # add the dynamical system to the non smooth dynamical system
    bouncingBall.nonSmoothDynamicalSystem().insertDynamicalSystem(ball)

    # link the interaction and the dynamical system
    bouncingBall.nonSmoothDynamicalSystem().link(inter,ball);

    #
    # Simulation
    #

    # (1) OneStepIntegrators
    OSI = Moreau(theta)
    OSI.insertDynamicalSystem(ball)
    OSI.setGamma(0)

    # (2) Time discretisation --
    t = TimeDiscretisation(t0,h)

    # (3) one step non smooth problem
    osnspb = LCP()

    # (4) Simulation setup with (1) (2) (3)
    s = TimeStepping(t)
    s.insertIntegrator(OSI)
    s.insertNonSmoothProblem(osnspb)

    # end of model definition

    #Observer Dynamics
    hatA = array([[l]])
    observer = FirstOrderLinearDS(array([z0]), hatA)
    observer.setComputebFunction("ObsBballPlugin.so","computeFExt")

    obsZ = array([0, 0, l, e])
    observer.setzPtr(obsZ)
    # Observer Relations
    obsRelation = FirstOrderType1R("ObsBballPlugin:comph0","ObsBballPlugin:compg0","ObsBballPlugin:compGradh","ObsBballPlugin:compGradg" )
    obsRelation.setComputeJachzFunction("ObsBballPlugin.so", "compF")

    obsCompNSL = ComplementarityConditionNSL(1)
    obsInteraction = Interaction(1,obsCompNSL, obsRelation)


    #
    # Model
    #
    obsBounceBall = Model(t0,T)

    # add the dynamical system to the non smooth dynamical system
    obsBounceBall.nonSmoothDynamicalSystem().insertDynamicalSystem(observer)

    # link the interaction and the dynamical system
    obsBounceBall.nonSmoothDynamicalSystem().link(obsInteraction,observer);


    #
    # Simulation
    #

    # (1) OneStepIntegrators
    obsOSI = Moreau(theta)
    obsOSI.insertDynamicalSystem(observer)

    # (2) Time discretisation --
    obst = TimeDiscretisation(t0,h)

    # (3) one step non smooth problem
    obslcp = LCP()

    # (4) Simulation setup with (1) (2) (3)
    obsTs = TimeStepping(obst)
    obsTs.insertIntegrator(obsOSI)
    obsTs.insertNonSmoothProblem(obslcp)

    # end of observer  model definition


    #
    # computation
    #

    # simulation initialization
    bouncingBall.initialize(s)

    # simulation initialization
    obsBounceBall.initialize(obsTs)

    # the number of time steps
    N = (T-t0)/h+1

    # Get the values to be plotted
    # ->saved in a matrix dataPlot

    dataPlot = empty((N, 10))


    #
    # numpy pointers on dense Siconos vectors
    #
    q = ball.q()
    v = ball.velocity()
    p = ball.p(1)
    lambda_ = inter.lambda_(1)


    #
    # numpy pointers on dense Siconos vectors
    #
    obsz = observer.x()
    obslambda = obsInteraction.lambda_(0)
    obsy = obsInteraction.y(0)

    obsq = observer.z()
    #
    # initial data
    #
    dataPlot[0, 0] = t0
    dataPlot[0, 1] = q[0]
    dataPlot[0, 2] = v[0]
    dataPlot[0, 3] = p[0]
    dataPlot[0, 4] = lambda_[0]
    dataPlot[0, 5] = obsz[0]
    dataPlot[0, 6] = obslambda[0]
    dataPlot[0, 7] = obsy[0]
    dataPlot[0, 8] = obsq[0]
    dataPlot[0, 9] = obsq[1]

    k = 1

    # time loop
    while(s.hasNextEvent()):
        observer.z()[0] = q[0]
        observer.z()[1] = obsz[0]
        s.computeOneStep()
        obsTs.computeOneStep()

        dataPlot[k, 0] = s.nextTime()
        dataPlot[k, 1] = q[0]
        dataPlot[k, 2] = v[0]
        dataPlot[k, 3] = p[0]
        dataPlot[k, 4] = lambda_[0]
        dataPlot[k, 5] = obsz[0]
        dataPlot[k, 6] = obslambda[0]
        dataPlot[k, 7] = obsy[0]
        dataPlot[k, 8] = obsq[0]
        dataPlot[k, 9] = obsq[1]

        k += 1
        s.nextStep()
        obsTs.nextStep()
    dataPlot.resize(k, 10)
    return dataPlot


def wrap_sim(tup):
    return tup + (run_sim(*tup), )

def drawFigs(simData, l, z0):
    for le in l:
        simResult = [i[-1] for i in simData if i[1] == le]
        fig = plt.figure()
        ax = fig.add_subplot(111)
        p = []
        p.append(ax.plot(simResult[0][:, 0], simResult[0][:, 2])[0])
        for tmpd in simResult:
            p.append(ax.plot(tmpd[:, 0], tmpd[:, 5] - le*tmpd[:, 1])[0])
        ax.grid(linewidth=0.3)
        z0l = [r',\quad z_0 = ' + str(i) + '$' for i in z0]
        legObs = map(lambda x, y: x+y, [r'$\hat{v}']*len(z0l), z0l)
        ax.legend(p, [r'$v$'] + legObs)
        ax.set_title(r'$l = ' + str(le) + '$')
        ax.set_xlabel(r'$t$')
#        fig.tight_layout(pad=0)
    plt.show()


if __name__ == '__main__':
    h = [1.0e-3]
    z0 = [-15]#z0 = [-15, 4, 15]
    l = [-0.9]#l = [-1, -5, -.3]
    allArgs = list(itertools.product(h, l, z0))
    print(allArgs)

    pool = Pool(processes=4)
    res = pool.map_async(wrap_sim, allArgs)

    simDataFull = list(res.get())

    drawFigs(simDataFull, l, z0)
