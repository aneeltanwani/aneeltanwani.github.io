import numpy as np
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib import rc


rc('text', usetex = 1)

dataBball = np.loadtxt('dataBball.txt')
Gain = -0.9
z0=-15


fig = plt.figure()
ax = fig.add_subplot(111)
p = [] # handle for plot elements
p.append(ax.plot(dataBball[:, 0], dataBball[:, 2])[0])
p.append(ax.plot(dataBball[:, 0], dataBball[:, 5] - Gain*dataBball[:, 1],'r--')[0])
ax.grid(linewidth=0.3)

#legObs = [r'$\hat v, \ \hat z_0 ='+str(z0)+'$']
legObs = [r'$\hat v$']
ax.legend(p, [r'$v$'] + legObs, prop={'size':24})
ax.set_xlabel(r'$t$')

plt.show()
