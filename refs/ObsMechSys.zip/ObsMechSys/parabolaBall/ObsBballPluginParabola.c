#include <stdio.h>
#include <math.h>

//0.0007
#define TOL_Q 0

void gradHconstraint(double* x, double* y)
{
	double norm=sqrt(1+4*x[1]*x[1]);
  y[1] = 1;
  y[0] = -2*x[0];
}

void comphq(double* q, double* hq)
{
  hq[0] = q[1] - q[0]*q[0];
}

void H(unsigned int sizeOfx, double* x, unsigned int sizeOfy, double* y, unsigned int sizeOfZ, double* z)
{
  comphq(x, y);
}

void jacHq(unsigned int sizeOfx, double* x,  unsigned int sizeOfy, double* y, unsigned int sizeOfZ, double* z)
{
  gradHconstraint(x, y);
}

void computeFExt(double time, unsigned int sizeOfB, double* b, unsigned int sizeOfZ, double* z)
{
  double Grav = 9.81;
  double l = z[sizeOfZ-2];
  b[0] = -Grav-l*l*z[0];
  b[1] = -l*l*z[1];
}


void comph0(unsigned int sizeOfx, double* x, unsigned int sizeOfy, double* y, unsigned int sizeOfZ, double* z)
{
//  printf("%f ", z[0]);
//  printf("%f\n", z[1]);
  double hq[1];
  comphq(z, hq);
  double eI = z[sizeOfZ-1];
  if (hq > TOL_Q)
  {
    y[0] = 1;
    y[1] = 1;
  }
  else
  {
    double N[2];
    double l = z[sizeOfZ-2];
    gradHconstraint(z, N);
    double coeff = ((z[2]- l*z[0])*N[0]+(z[3]-l*z[1])*N[1])/(N[0]*N[0] + N[1]*N[1]);
    y[0] = (x[0] -l*z[0]) - (z[2] - l*z[0]) + (1+eI)*coeff*N[0];
    y[1] = (x[1] -l*z[1]) - (z[3] -l*z[1]) + (1+eI)*coeff*N[1];
//    printf("q = %f ", z[0]);
//    printf("z_k = %f ", z[1]);
//    printf("x = %f ", x[0]);
//    printf("y = %f\n", y[0]);

  }

}

void computeB(double time, unsigned int sizeOfB1, unsigned int sizeOfB2, double* B, unsigned int sizeOfZ, double* z)
{
  double hq[1];
  comphq(z, hq);
  if (hq[0] > TOL_Q)
  {
    B[0] = 0;
    B[1] = 0;
  }
  else
  {
    gradHconstraint(z, B);
  }
}

void computeC(double time, unsigned int sizeOfC1, unsigned int sizeOfC2, double* C, unsigned int sizeOfZ, double* z)
{
  double hq[1];
  comphq(z, hq);
  if (hq[0] > TOL_Q)
  {
    C[0] = 0;
    C[1] = 0;
  }
  else
  {
    gradHconstraint(z, C);
  }
}

void computeE(double time, unsigned int sizeOfE, double* e, unsigned int sizeOfZ, double* z)
{
  double hq[1];
  comphq(z, hq);
  double eI = z[sizeOfZ-1];
  if (hq[0] > TOL_Q)
  {
    e[0] = 10;
  }
  else
  {
    double N[2];
    double l = z[sizeOfZ-2];
    gradHconstraint(z, N);
    double coeff = (eI*z[2]-(1+eI)*l*z[0])*N[0]+(eI*z[3]-(1+eI)*l*z[1])*N[1];
    e[0] = coeff;
  }

}
