import numpy as np
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
import matplotlib.animation as animation

# This example uses subclassing, but there is no reason that the proper function
# couldn't be set up and then use FuncAnimation. The code is long, but not
# really complex. The length is due solely to the fact that there are a total
# of 9 lines that need to be changed for the animation as well as 3 subplots
# that need initial set up.

dataPball = np.loadtxt('dataBPara.txt')
Gain = -0.5
cnt = 0
Btime = []
BPosx = []
BPosy = []
BVelx = []
BVely = []
Vestx = []
Vesty = []

while cnt < dataPball[:,0].size:
	Btime.append(dataPball[cnt,0])
	BPosx.append(dataPball[cnt,2])
	BPosy.append(dataPball[cnt,1])
	BVelx.append(dataPball[cnt,4])
	BVely.append(dataPball[cnt,3])
	Vestx.append(dataPball[cnt,8]-Gain*dataPball[cnt,1])
	Vesty.append(dataPball[cnt,9]-Gain*dataPball[cnt,2])
	cnt+=5

class SubplotAnimation(animation.TimedAnimation):
	def __init__(self):
		fig = plt.figure()
		ax1 = fig.add_subplot(211)
		ax2 = fig.add_subplot(212)
		
		self.t = np.array(Btime).reshape(-1,1)
		self.posx = np.array(BPosx).reshape(-1,1)
		self.posy = np.array(BPosy).reshape(-1,1)
		self.velx = np.array(BVelx).reshape(-1,1)
		self.vely = np.array(BVely).reshape(-1,1)
		self.estx = np.array(Vestx).reshape(-1,1)
		self.esty = np.array(Vesty).reshape(-1,1)
		
		ax1.set_xlabel('X-axis')
		ax1.set_ylabel('Y-axis')
		self.line1 = Line2D([], [], color='r', marker='o', markeredgecolor='black', markersize=8)
		self.line1a = Line2D([], [], color='r', marker='o', markeredgecolor='r', markersize=4)
		self.lineCon = Line2D([], [], color ='black', linewidth=2)
		ax1.add_line(self.line1)
		ax1.add_line(self.line1a)
		ax1.add_line(self.lineCon)
		ax1.set_xlim(-8,8)
		ax1.set_ylim(-1,15)
		ax1.grid()
		ax1.set_title('Observer for Ball Bouncing in a Parabola')
		
		ax2.set_xlabel('Time')
		ax2.set_ylabel('Velocity')
		self.linex = Line2D([], [], color = 'blue', linewidth=2)
		self.liney = Line2D([], [], color = 'red', linewidth=2)
		self.linexe = Line2D([], [], color = 'blue', linestyle='--', linewidth=2)
		self.lineye = Line2D([], [], color = 'red', linestyle='--', linewidth=2)
		ax2.add_line(self.linex)
		ax2.add_line(self.liney)
		ax2.add_line(self.linexe)
		ax2.add_line(self.lineye)
		ax2.legend([self.liney, self.linex, self.lineye, self.linexe], [r'$v_x$', r'$v_y$', r'$\hat{v}_x$', r'$\hat{v}_y$'], ncol=4)
		ax2.set_xlim(0,10)
		ax2.set_ylim(-15,20)
		ax2.grid()
		
		animation.TimedAnimation.__init__(self, fig, interval=20, blit=True)

	def _draw_frame(self, framedata):
		i = framedata
		head = i-1
		head_slice = (self.t > self.t[i] - 1.0) & (self.t < self.t[i])
		
		self.line1a.set_data(self.posy[head_slice], self.posx[head_slice])
		self.line1.set_data(self.posy[i],self.posx[i])
		
		self.linex.set_data(self.t[:i],self.velx[:i])
		self.liney.set_data(self.t[:i],self.vely[:i])
		self.linexe.set_data(self.t[:i],self.estx[:i])
		self.lineye.set_data(self.t[:i],self.esty[:i])
		
		self._draw_artists = [self.line1, self.line1a,
			self.linex, self.liney, self.linexe, self.lineye]

	def new_frame_seq(self):
		return iter(range(len(self.t)))

	def _init_draw(self):
		self.lineCon.set_data(np.linspace(-5,5,len(self.t)), np.linspace(-5,5,len(self.t))**2)
		lines = [self.line1, self.line1a,
			self.linex, self.liney, self.linexe, self.lineye]
		for l in lines:
			l.set_data([], [])

ani = SubplotAnimation()
#ani.save('Parabola.mov', extra_args=['-vcodec', 'libxvid'],dpi=200,bitrate=4000)
plt.show()
