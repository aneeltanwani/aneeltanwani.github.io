import numpy as np
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib import rc


rc('text', usetex = 1)

dataPara = np.loadtxt('dataBPara.txt')
Gain = -0.5
z0=-15


fig = plt.figure()

pos = fig.add_subplot(311)
p = []
p.append(pos.plot(np.linspace(-5,5,len(dataPara[:, 0])), np.linspace(-5,5,len(dataPara[:, 0]))**2)[0])
p.append(pos.plot(dataPara[:, 2], dataPara[:, 1])[0],)
pos.grid(linewidth = 0.3)
pos.legend(p, [r'$h(q)=0$']+[r'$q$'])

ax = fig.add_subplot(312)
p = [] # handle for plot elements
p.append(ax.plot(dataPara[:, 0], dataPara[:, 4])[0])
p.append(ax.plot(dataPara[:, 0], dataPara[:, 9] - Gain*dataPara[:, 2],'r--')[0])
ax.grid(linewidth=0.3)

#legObs = [r'$\hat v, \ \hat z_0 ='+str(z0)+'$']
legObs = [r'$\hat v_x$']
ax.legend(p, [r'$v_x$'] + legObs)
ax.set_xlabel(r'$t$')

ax = fig.add_subplot(313)
p = [] # handle for plot elements
p.append(ax.plot(dataPara[:, 0], dataPara[:, 3])[0])
p.append(ax.plot(dataPara[:, 0], dataPara[:, 8] - Gain*dataPara[:, 1],'r--')[0])
ax.grid(linewidth=0.3)

#legObs = [r'$\hat v, \ \hat z_0 ='+str(z0)+'$']
legObs = [r'$\hat v_y$']
ax.legend(p, [r'$v_y$'] + legObs)
ax.set_xlabel(r'$t$')

plt.show()